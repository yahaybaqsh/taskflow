import { loadTasks, saveTasks } from "../storage.ts";

export function deleteTask(id: number): void {
  const tasks = await loadTasks();
  const index = tasks.findIndex(t => t.id === id);
  if (index === -1) {
    console.log(`❌ لم يتم العثور على مهمة بالرقم ${id} - delete.ts:7`);
    return;
  }
  const deleted = tasks.splice(index, 1)[0];
  await saveTasks(tasks);
  console.log(`🗑️ تم حذف المهمة: "${deleted.text}" - delete.ts:12`);
}