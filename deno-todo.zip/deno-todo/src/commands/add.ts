import { loadTasks, saveTasks, Task } from "../storage.ts";

export function add(text: string): void {
  const tasks = await loadTasks();
  const newTask: Task = {
    id: tasks.length > 0 ? Math.max(...tasks.map(t => t.id)) + 1 : 1,
    text,
    completed: false,
    createdAt: new Date().toISOString(),
  };
  tasks.push(newTask);
  await saveTasks(tasks);
  console.log(`✅ تم إضافة المهمة: "${text}" - add.ts:13`);
}