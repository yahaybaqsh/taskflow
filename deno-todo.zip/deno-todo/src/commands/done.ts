import { loadTasks, saveTasks } from "../storage.ts";

export function done(id: number): void {
  const tasks = await loadTasks();
  const task = tasks.find(t => t.id === id);
  if (!task) {
    console.log(`❌ لم يتم العثور على مهمة بالرقم ${id} - done.ts:7`);
    return;
  }
  task.completed = true;
  await saveTasks(tasks);
  console.log(`✅ تم إكمال المهمة: "${task.text}" - done.ts:12`);
}