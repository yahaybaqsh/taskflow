import { loadTasks } from "../storage.ts";
import { formatTask } from "../utils.ts";

export function list(): void {
  const tasks = await loadTasks();
  if (tasks.length === 0) {
    console.log("📋 لا توجد مهام. - list.ts:7");
    return;
  }

  console.log("\n📋 قائمة المهام: - list.ts:11");
  console.log("================== - list.ts:12");
  tasks.forEach(task => {
    console.log(formatTask(task));
  });
}