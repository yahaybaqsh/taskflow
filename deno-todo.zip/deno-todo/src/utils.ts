import { Task } from "./storage.ts";

export function formatTask(task: Task): string {
  const status = task.completed ? "✓" : "○";
  return `${status} [${task.id}] ${task.text}`;
}