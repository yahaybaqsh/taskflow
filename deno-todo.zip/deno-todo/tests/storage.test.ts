import { loadTasks, saveTasks } from "../src/storage.ts";
import { assertEquals } from "https://deno.land/std@0.224.0/testing/asserts.ts";

Deno.test("يجب أن يعيد loadTasks مصفوفة فارغة إذا لم يكن الملف موجودًا", async () => {
  const tasks = await loadTasks();
  assertEquals(tasks, []);
});

Deno.test("يجب أن يحفظ المهام ويقرأها بدقة", async () => {
  const tasks = [
    { id: 1, text: "اختبار 1", completed: false, createdAt: new Date().toISOString() },
  ];
  await saveTasks(tasks);
  const loaded = await loadTasks();
  assertEquals(loaded, tasks);
});