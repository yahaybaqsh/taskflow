import { assertEquals } from "https://deno.land/std@0.224.0/testing/asserts.ts";
import { run } from "https://deno.land/std@0.224.0/testing/bench.ts";

// اختبار بسيط: التحقق من أن الأمر --version يعمل
Deno.test("يجب أن يعرض --version الإصدار الصحيح", async () => {
  const output = await Deno.run({
    cmd: ["deno", "run", "--allow-read", "--allow-write", "../mod.ts", "--version"],
    stdout: "piped",
    stderr: "piped",
  }).output();
  const text = new TextDecoder().decode(output);
  assertEquals(text.trim(), "deno-todo v1.0.0");
});